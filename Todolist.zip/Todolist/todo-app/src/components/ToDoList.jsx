import React, { useState, useEffect } from "react";

const ToDoList = () => {
    const [tasks, setTasks] = useState([]);
    const [input, setInput] = useState("");

    // Load tasks from localStorage
    useEffect(() => {
        const savedTasks = JSON.parse(localStorage.getItem("tasks")) || [];
        setTasks(savedTasks);
    }, []);

    // Save tasks to localStorage
    useEffect(() => {
        localStorage.setItem("tasks", JSON.stringify(tasks));
    }, [tasks]);

    const addTask = () => {
        if (input.trim()) {
            setTasks([...tasks, { text: input, completed: false }]);
            setInput("");
        }
    };

    const toggleTask = (index) => {
        const updatedTasks = tasks.map((task, i) =>
            i === index ? { ...task, completed: !task.completed } : task
        );
        setTasks(updatedTasks);
    };

    const deleteTask = (index) => {
        setTasks(tasks.filter((_, i) => i !== index));
    };

    const clearTasks = () => {
        setTasks([]);
    };

    return (
        <div className="todo-container">
            <h1>To-Do List</h1>
            <div className="input-container">
                <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Enter a task"
                    className="todo-input"
                />
                <button onClick={addTask} className="add-button">
                    Add
                </button>
            </div>
            <ul className="task-list">
                {tasks.map((task, index) => (
                    <li
                        key={index}
                        className={`task-item ${task.completed ? "completed" : ""}`}
                        onClick={() => toggleTask(index)}
                    >
                        {task.text}
                        <button
                            onClick={(e) => {
                                e.stopPropagation(); // Prevent toggle on delete
                                deleteTask(index);
                            }}
                            className="delete-button"
                        >
                            Delete
                        </button>
                    </li>
                ))}
            </ul>
            {tasks.length > 0 && (
                <button onClick={clearTasks} className="clear-button">
                    Clear All
                </button>
            )}
        </div>
    );
};

export default ToDoList;
